module.exports = {
    host: 'localhost',
    username: 'root',
    password: ''
}